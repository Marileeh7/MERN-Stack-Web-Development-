console.log("page loaded...");
function reproducir(element) {
    element.play();
    element.muted=true;
}
function pausa(element) {
    element.pause();
}